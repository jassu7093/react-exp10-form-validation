// routes/userRoutes.js
const express = require('express');
const router = express.Router();
const User = require('../models/userModel');

// CREATE user
router.post('/', async (req, res, next) => {
  try {
    const user = new User(req.body);
    const saved = await user.save();
    res.status(201).json({ message: 'User registered successfully ✅', saved });
  } catch (err) {
    // Mongoose validation errors are caught here
    if (err.name === 'ValidationError') {
      const messages = Object.values(err.errors).map(val => val.message);
      return res.status(400).json({ success: false, errors: messages });
    }
    next(err);
  }
});

// READ all users
router.get('/', async (req, res) => {
  const users = await User.find();
  res.status(200).json(users);
});

module.exports = router;
